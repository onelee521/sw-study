package com.ohgireffers.section01.xmlconfig;

import java.util.List;

public class MenuController {
    private final MenuService menuService;  // controller 다음에는 servive
    private final PrintResult printResult;  // 결과 페이지에 해당하는 (view 개념의) 클래스

    public MenuController() {
        menuService = new MenuService();
        printResult = new PrintResult();
    }

    public void findAllMenus() {

        List<MenuDTO> menuList = menuService.findAllMenus();
//        System.out.println("menuList = " + menuList);

        if(menuList.isEmpty()) {
            printResult.printMenus(menuList);
        } else {
            printResult.printErrorMessage("조회할 메뉴가 없습니다.");
        }

    }
}
